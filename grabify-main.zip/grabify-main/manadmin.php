<style>
<?php include 'css/style.css'; ?>
<?php include 'css/admin.css'; ?>

</style>
<header>
  <hgroup>
    <h1>Grabify Admin Page</h1>
    <h1>Welcome XXX Admin </h1>
    <a href="home.php">&larr; visit website</a>
    <br>
    <h1 style="text-align:center;"> Admin Management Page
    <div class="line"></div>

  </hgroup>
</header>

<nav>
  <ul>
    <li><a class="brick dashboard" href="#"><span class='icon ion-home'></span>Dashboard</a></li>
    <li><a class="brick pending" href="#"><span class='icon ion-gear-a'></span>Pending Business</a></li>
    <li><a class="brick pages" href="#"><span class='icon ion-document'></span>Reviews</a></li>
    <li><a class="brick users" href="#"><span class='icon ion-person'></span>Users</a></li>
    <li><a class="brick settings" href="#"><span class='icon ion-gear-a'></span>Website Settings</a></li>


  </ul>
</nav>
<div id="content" class="pages">


    <div class="brick title">
      <h2>Home Page</h2>
    </div>

  </header>



  <div class="brick closed">
    <hgroup>
      <h2>Dashboard</h2>
      <a href="#" class="icon ion-close js-close close"></a>
      <form>
        <input type="text" />
      </form>
    </hgroup>
  </div>
  
  <div class="brick closed">
    <hgroup>
      <h2>Pending Business</h2>
      <a href="#" class="icon ion-close js-close close"></a>
      <form>
        <input type="text" />
      </form>
    </hgroup>
  </div>


  <div class="brick closed">
    <hgroup>
      <h2>Reviews</h2>
      <a href="#" class="icon ion-close js-close close"></a>
      <form>
        <textarea></textarea>
      </form>
    </hgroup>
  </div>

  <div class="brick closed">
    <hgroup>
      <h2>Users</h2>
      <a href="#" class="icon ion-close js-close close"></a>
      <form>
        <textarea></textarea>
      </form>
    </hgroup>
  </div>
  <div class="brick closed">
    <hgroup>
      <h2>Website Settings</h2>
      <a href="#" class="icon ion-close js-close close"></a>
      <form>
        <textarea></textarea>
      </form>
    </hgroup>
  </div>



</div>

<footer>

</footer>

