# SWAP GROUP 4 

## Group members 
1. Haowen

2. Jeric 

3. Bryan 

4. Clarence  

5. Benjamin
