<html lang="en">
	<head>
  <style>
<?php include 'css/biswait.css'; ?>
  </style>
		<title></title>
		<meta charset="UTF-8">
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<link href="assets/css/style.css" rel="stylesheet">
	</head>
	<body>
		<section class="row">
			<div class="content">
				<div>
					<img src="https://upload.wikimedia.org/wikipedia/commons/thumb/e/e0/SNice.svg/220px-SNice.svg.png" width="50" height="50" alt="Logo Marjorie Lazaro" />
					<h1>Grabify</h1>
					<h2>Ecommerce website</h2>
					<p class="new">
						Your Account is waiting for Approval

					</p>
					<p>
						Go Back to Viewing:<br />
						<a href="home.php" >Back to Website</a><br />
					</p>
				</div>
			</div>
		</section>
	</body>
</html>

