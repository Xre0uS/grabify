<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Grabify Admin</title>
    <style>
        <?php include 'css/styles.css'; ?>
    </style>
</head>

<body>
    <?php include 'php/navbar.php'; ?>
    
</body>

</html>